$(document).ready(function() {
    'use strict';
/* THIS IS IDENTICAL TO SERVICER.JS EXCEPT FOR THE REMOVAL OF THE CLIENT-BOX CODE AT THE END OF SERVICER.JS
THIS PROBLEM WILL GO AWAY WHEN WE OBJECTIFY EVERYTHING IN THE NEXT RELEASE*/
    rta.Parcel.prototype = {
        populateInfoWindowData: function () {
            rta.populateInfoWindowData(this);
        },
        title: function () {
            return rta.title(this);
        }
    };
    var compMarkers = [],
        compLines = [],
        targetMarker,
        county,
        beautifiedAddress,
        comps = [],// the actual comps, up to five of them
        ageAppropriateComps = [], //a subset of the parcels in the polygon that are of an appropriate age
        currentParcel,
        targetParcel,
        ourVertices = [],
        ourLines = [],
        parcels = [],
        globalSubscript,
        lastClick = null,
        AGEDELTA = 2, //max difference in houses ages for being a comp
        infoBoxOptions = {
            content: document.getElementById('infoWindowData')
        },
        infoWindow = new InfoBox(infoBoxOptions),
        mapCanvas = new google.maps.Map(document.getElementById('mapCanvasDiv'), {
            zoom : 4,
            center : new google.maps.LatLng(35.99, -96.92),
            scaleControl : true,
            draggableCursor : 'crosshair',
            streetViewControl : true,
            mapTypeId : google.maps.MapTypeId.HYBRID,
            mapTypeControlOptions : {
                style: google.maps.MapTypeControlStyle.HORIZONTAL
            }
        }),
        bounds,
        rtaAlert = function rtaAlert(message) {
            $('#dialog-text').text(message);
            $('#dialog').dialog({
                modal: true,
                position: {my: "left top", at: "left+10% bottom-30%", of: '#control-panel'}
            });
        },
        mapCenter = mapCanvas.getCenter();
    $('.magic').each(function() { this.magicTemplate = $(this).html(); }).empty().filter('tr').hide();
    function populateMagic($elem, info) {
        $elem.find('.magic:not(tr)').each(function() {
            $(this).html(rta.interpolate(this.magicTemplate, info));
        });
        $elem.find('.magic-made').remove();
        $elem.find('tr.magic').after(function() {
            var magic = this;
            return info.comps.map(function(comp) {
                return $(magic).clone().removeClass('magic').addClass('magic-made').show()
                    .html(rta.interpolate(magic.magicTemplate, {info:info, comp:comp, distance:rta.calculateDistance(comp, info.target)}));
            });
        });
        return $elem;
    }
    function enableListener(marker) {
        google.maps.event.addListener(marker, 'click', function () {
            var clickedMarker = this,
                clickedParcel = clickedMarker.parcel;
            currentParcel = clickedParcel;
            if (!mapCenter) mapCenter = mapCanvas.getCenter();
            clickedMarker.parcel.populateInfoWindowData();
            $('#infoWindowData').css('display', 'block');
            infoWindow.setContent('<div id =infoWindowData>' + $('#infoWindowData').html() + '</div>');
            infoWindow.open(mapCanvas, clickedMarker);
        });
    }
    function formatAnswers(field, condition) {
        switch (condition) {
            case 0:
                field.text('No');
                break;
            case 1:
                field.text('Yes');
                break;
            default:
                field.text('?');
        }
    }
    function gotAddress() {
        lastClick = 'address';
        $('#working').show();
        rta.Parcel.byAddress($('#address').val(), function success(info) {
                bounds = new google.maps.LatLngBounds();
                beautifiedAddress = info.beautifiedAddress;
                if (targetMarker){
                    targetMarker.setMap(null);
                }
                targetMarker = null;
                if(compMarkers.length > 0) {
                    compMarkers.forEach(function(marker) {marker.setMap(null);});
                }
                compMarkers = [];
                if (compLines.length > 0) {
                    compLines.forEach( function(line) {line.setMap(null);});
                }
                compLines = [];
                targetParcel = info.parcel;
                county = targetParcel.county;
                targetMarker = new google.maps.Marker({position: targetParcel.geoPos, map : mapCanvas, title: targetParcel.partialAddress});
                targetMarker.setIcon(new google.maps.MarkerImage('../shared/images/yellow-16x26.png'));
                targetMarker.parcel = targetParcel;
                enableListener(targetMarker);
                bounds.extend(targetParcel.geoPos);
                mapCanvas.setCenter(targetParcel.geoPos);
                mapCanvas.setZoom(16);
                var exemptionInfo = '';
                $('#property-address').text(info.beautifiedAddress);
                $('#property-owner').text(targetParcel.ownerNames);
                $('#property-age').text(targetParcel.houseAge + ' years old, (effectively) built in ' + targetParcel.houseYearBuilt);
                $('#property-house-value').text(rta.addCommas(targetParcel.houseNumSqft) + ' sqft @ $ ' + rta.addCommas(targetParcel.houseValPerSqft.toFixed(2)) +
                    '/sqft  \t $ ' + rta.addCommas(targetParcel.houseVal));
                $('#property-land-value').text('$ ' + rta.addCommas(targetParcel.landVal));
                $('#property-total-value').text('$ ' + rta.addCommas(targetParcel.totalVal));
                $('#property-taxes').text(targetParcel.totalTaxDesc);
                $('#exemption-homestead-value').text(targetParcel.homesteadWorthDesc);
                formatAnswers($('#exemption-homestead-eligible'),targetParcel.homesteadable);
                formatAnswers($('#exemption-homestead-taken-text'),targetParcel.homesteaded);
                if(targetParcel.homesteadable && !targetParcel.homesteaded) {
                    $('#exemption-homestead-taken-text').css('color', 'red');
                } else {
                    $('#exemption-homestead-taken-text').css('color', 'darkblue');
                }
                formatAnswers($('#exemption-65-taken'),targetParcel.senior);
                formatAnswers($('#exemption-disabled-taken'),targetParcel.disabled);
                formatAnswers($('#exemption-vet-taken'),targetParcel.vet);
                $('#exemption-deferred-value').text(targetParcel.totalTaxDesc);
                if ((targetParcel.senior === 1) ||(targetParcel.disabled === 1) ||(targetParcel.vet === 1)) {
                    $('#exemption-deferred-eligible').text('Yes');
                } else {
                    $('#exemption-deferred-eligible').text('No');
                }
                formatAnswers($('#exemption-deferred-taken-text'),targetParcel.deferred);
                if(($('#exemption-deferred-eligible').text() === 'Yes') && !targetParcel.deferred) {
                    $('#exemption-deferred-taken-text').css('color', 'red');
                } else {
                    $('#exemption-deferred-taken-text').css('color', 'darkblue');
                }
                info.target = targetParcel;
                $('#exemptions').show();
                populateMagic($('#success'), info).show();
                $('#comps').hide();
                $('#failure').hide();
                $('#working').hide();
            },
            function(info) {
                rtaAlert('That address is not in our database');
                lastClick = null;
                $('#success').hide(); $('#working').hide();
            }
        );
    }

    function processComps() {
        $('#comps').hide();
        $('#failure').hide();
        var assessment = new rta.AssessedParcel(targetParcel, comps);
        var avgPerSqft = assessment.averageComp('houseValPerSqft');
        if (assessment.comps.length) {
            var info = {
                    target: targetParcel,
                    comps: assessment.comps,
                    savingsVal: (targetParcel.houseValPerSqft - avgPerSqft) * targetParcel.houseNumSqft,  // $savings
                    savingsPct: 100 * (targetParcel.houseValPerSqft - avgPerSqft) / (targetParcel.houseValPerSqft || 1),  // %savings
                    avgCompHouseValPerSqft: avgPerSqft,
                    newHouseVal: avgPerSqft * targetParcel.houseNumSqft,
                    taxVal: targetParcel.savingsWorth * (targetParcel.houseValPerSqft - avgPerSqft) * targetParcel.houseNumSqft,
                    numPotentialComps: parcels.length
                },
                newTaxes = 100 * Math.round((targetParcel.totalTaxVal - targetParcel.savingsWorth *
                    (targetParcel.houseValPerSqft - avgPerSqft) * targetParcel.houseNumSqft) / 100),
                newTaxesPct = 100 * (targetParcel.totalTaxVal - newTaxes) / targetParcel.totalTaxVal,
                newTotalVal = targetParcel.totalVal - targetParcel.houseVal +
                    Math.round(targetParcel.houseNumSqft * avgPerSqft),
                newTotalValPct = 100.0 * (info.target.totalVal - newTotalVal) / info.target.totalVal;
            populateMagic($('#comps'), info).show();
            $('#reduction-previous-rate').text(rta.addCommas(targetParcel.houseValPerSqft.toFixed(2)));
            $('#reduction-previous-value').text(rta.addCommas(targetParcel.houseVal));
            $('#reduction-previous-total').text(rta.addCommas(targetParcel.totalVal));
            $('#reduction-previous-taxes').text(rta.addCommas(targetParcel.totalTaxVal));
            $('#reduction-new-rate').text(rta.addCommas(avgPerSqft.toFixed(2)));
            $('#reduction-new-value').text(rta.addCommas(Math.round(targetParcel.houseNumSqft * avgPerSqft)));
            $('#reduction-new-total').text(rta.addCommas(Math.round(newTotalVal)));
            $('#reduction-new-taxes').text(rta.addCommas(Math.round(newTaxes)));
            $('#reduction-diff-rate').text(rta.addCommas((targetParcel.houseValPerSqft - avgPerSqft).toFixed(2)));
            $('#reduction-diff-value').text(rta.addCommas(Math.round(targetParcel.houseVal - info.newHouseVal)));
            $('#reduction-diff-total').text(rta.addCommas(Math.round(targetParcel.houseVal - info.newHouseVal)));
            $('#reduction-diff-taxes').text(rta.addCommas(targetParcel.totalTaxVal - newTaxes));
            $('#reduction-pct-rate').text(rta.addCommas(Math.round(info.savingsPct)));
            $('#reduction-pct-value').text(rta.addCommas(Math.round(info.savingsPct)));
            $('#reduction-pct-total').text(rta.addCommas(Math.round(newTotalValPct)));
            $('#reduction-pct-taxes').text(rta.addCommas(Math.round(newTaxesPct)));
            $('#comps').show();
        } else {
            rtaAlert('No qualified comps for ' + targetParcel.partialAddress);
        }
    }

    $('#address').keypress(function(e) {
        if (e.which === 13) {
            gotAddress();
        }
    });

    $('#address').blur(function() {
        $(this).attr('required', 'required');  // so the errmsg doesn't appear upon initial page-load
    });

    $('.override').click(function() {
        return false;  // stop the 'click' event from propagating
    });
    $('#neighborhood-begin').click(function () {
        lastClick = 'neighborhood-begin';
        ourVertices = [];
        ourLines.forEach(function (line) {
            line.setMap(null);
        });
        ourLines = [];
        if (compLines.length > 0) {
            compLines.forEach( function(line) {line.setMap(null);});
        }
        compLines = [];
        google.maps.event.addListener(mapCanvas, 'click', function (event) {
            var vertexCount = ourVertices.push(event.latLng);
            bounds.extend(event.latLng);
            if (vertexCount >= 2) {
                ourLines.push(new google.maps.Polyline({
                    path: [ourVertices[vertexCount - 2], ourVertices[vertexCount - 1]],
                    strokeColor: "#FFF000",
                    strokeWeight: 2,
                    map: mapCanvas
                }));
            }
        });
    });
    $('#neighborhood-end').click(function () {
        if ((ourVertices.length === 0)|| (lastClick != 'neighborhood-begin')) {
            rtaAlert('Cannot end something that has not been started!!');
            return;
        }
        if (ourVertices.length < 3) {
            rtaAlert('You have to enter at least three points before we can complete the polygon');
            return;
        }
        lastClick = 'neighborhood-end';
        var countBuckets = [0, 0, 0, 0, 0],  // how many parcels are in each quintile
            quintileSize,
            marker,
            NUMBUCKETS = 5,
            minVal = 999999999,
            maxVal = -1;
        google.maps.event.clearListeners(mapCanvas, 'click');
        parcels.forEach(function (parcel) {
            parcel.marker.setMap(null);
            parcel.marker = null;
        });
        parcels = [];
        ourLines.push(new google.maps.Polyline({
            path: [ourVertices[ourVertices.length - 1], ourVertices[0]],
            strokeColor: "#FFF000",
            strokeWeight: 2,
            map: mapCanvas
        }));
        county.getParcels(new rta.GeoPolygon(ourVertices), function (data) {
            var icons = [new google.maps.MarkerImage('../shared/images/blue-16x26.png'),
                new google.maps.MarkerImage('../shared/images/green-16x26.png'),
                new google.maps.MarkerImage('../shared/images/orange-16x26.png'),
                new google.maps.MarkerImage('../shared/images/pink-16x26.png'),
                new google.maps.MarkerImage('../shared/images/red-16x26.png')];
            parcels = data.filter(function (parcel) {
                if (parcel.houseValPerSqft < targetParcel.houseValPerSqft) {
                    marker = new google.maps.Marker({position: parcel.geoPos, map : mapCanvas, title: parcel.title()});
                    marker.parcel = parcel;
                    parcel.marker = marker;
                    minVal = Math.min(minVal, parcel.houseValPerSqft);
                    maxVal = Math.max(maxVal, parcel.houseValPerSqft);
                    enableListener(marker);
                    return true;
                }  else {
                    return false;
                }
            });
            quintileSize = (maxVal <= minVal) ? 1 : (maxVal - minVal) / NUMBUCKETS;
            parcels.forEach(function (parcel, i) {
                var slot = Math.min(Math.floor((parcel.houseValPerSqft - minVal) / quintileSize), 4);
                countBuckets[slot]++;
                parcel.marker.setIcon(icons[slot]);
                bounds.extend(parcel.geoPos);
            });
            mapCanvas.fitBounds(bounds);
            countBuckets.forEach(function (bucket, k) {
                $('#tableCount' + k).text(rta.addCommas(bucket));
                $('#tableRange' + k).text(
                    rta.addCommas(Math.floor((minVal + k * quintileSize)).toFixed(2)) + '-' +
                        rta.addCommas(Math.floor((minVal + (k + 1) * quintileSize)).toFixed(2)) );
            });
            $('#tableCount5').text(rta.addCommas(parcels.length));
            $('#tableRange5').text(rta.addCommas(Math.floor(minVal).toFixed(2)) + '-' +
                rta.addCommas(Math.floor(maxVal).toFixed(2)));
        });
    });
    $('#conservative-comps').click(function () {
        lastClick = 'conservative-comps';
        if (ourVertices.length > 2) {
            if (compLines.length > 0) {
                compLines.forEach( function(line) {line.setMap(null);});
            }
            compLines = [];
            ageAppropriateComps = parcels.filter(function isCompEligible(parcel) {
                return (parcel.houseAge <= (targetParcel.houseAge + AGEDELTA));
            });
            comps = ageAppropriateComps.sort(function compareHouseValPerSqft(a, b) {
                return a.houseValPerSqft - b.houseValPerSqft;
            }).slice(0,5);
            compLines = comps.map(function(comp) {return new google.maps.Polyline({
                path:[targetParcel.geoPos, comp.geoPos], map: mapCanvas, strokeColor: "#ffffff", strokeWeight: 3,
                strokeOpacity: 1.0});});
            processComps();
        } else {
            rtaAlert('Please define a neighborhood first');
        }
    });
    $('#aggressive-comps').click(function () {
        lastClick = 'aggressive-comps';
        if (ourVertices.length > 2) {
            if (compLines.length > 0) {
                compLines.forEach( function(line) {line.setMap(null);});
            }
            compLines = [];
            ageAppropriateComps = parcels;
            comps = ageAppropriateComps.sort(function compareHouseValPerSqft(a, b) {
                return a.houseValPerSqft - b.houseValPerSqft;
            }).slice(0,5);
            compLines = comps.map(function(comp) {return new google.maps.Polyline({
                path:[targetParcel.geoPos, comp.geoPos], map: mapCanvas, strokeColor: "#FFFFFF", strokeWeight: 3,
                strokeOpacity: 1.0});});
            processComps();
        } else {
            rtaAlert('Please define a neighborhood first');
        }
    });
    $('#manual-add').click(function () {
        lastClick = 'manual-add';
        if (currentParcel !== null) {
            if (currentParcel.id == targetParcel.id) {
                rtaAlert('You cannot use the target as its own comp');
            } else {
                var i = comps.indexOf(currentParcel);
                if (i < 0) {
                    comps.push(currentParcel);
                    comps = comps.sort(function compareHouseValPerSqft(a, b) {
                        return a.houseValPerSqft - b.houseValPerSqft;
                    });
                    compLines.push(new google.maps.Polyline({path:[targetParcel.geoPos, currentParcel.geoPos], map: mapCanvas,
                        strokeColor: "#FFFFFF", strokeWeight: 3, strokeOpacity: 1.0}));
                    infoWindow.close();
                    currentParcel= null;
                    processComps();
                }  else {
                    rtaAlert('That house is already being used as a comp');
                }
            }
        }   else {
            rtaAlert('Please click on a property first');
        }
    });
    $('#manual-delete').click(function () {
        lastClick = 'manual-delete';
        if (currentParcel !== null) {
            if (currentParcel.id == targetParcel.id) {
                rtaAlert('You cannot use the target as its own comp');
            } else {
                var i = comps.indexOf(currentParcel);
                if (i < 0) {
                    rtaAlert('That house is not being used as a comp, so cannot be removed.');
                }  else {
                    comps.splice(i, 1);
                    comps = comps.sort(function compareHouseValPerSqft(a, b) {
                        return a.houseValPerSqft - b.houseValPerSqft;
                    });
                    if (compLines.length > 0) {
                        compLines.forEach( function(line) {line.setMap(null);});
                    }
                    compLines = comps.map(function(comp) {return new google.maps.Polyline({
                        path:[targetParcel.geoPos, comp.geoPos], map: mapCanvas, strokeColor: "#FFFFFF", strokeWeight: 3,
                        strokeOpacity: 1.0});
                    });
                    infoWindow.close();
                    currentParcel = null;
                    processComps();
                }
            }
        }   else {
            rtaAlert('Please click on a property first');
        }
    });
    $('#save-button').click(function () {
        rtaAlert("The implementation of 'Upload' will be based on the client's needs for data sharing and storage.");
    });
    $('#view-button').click(function () {
        rtaAlert("The implementation of 'View' will be based on the client's needs for data formatting.");
    })
    google.maps.event.addListener(infoWindow,'closeclick',function(){
        if(mapCenter) mapCanvas.panTo(mapCenter);
        mapCenter = null;
        currentParcel = null;
    });
    ['zoom_changed', 'dragend', 'dragstart', 'drag', 'projection_changed', 'resize', 'tilt_changed'].forEach(
        function(eventName) {
            google.maps.event.addListener(mapCanvas, eventName, function() {
                mapCenter = null;
            });
        });
    $('#address').focus(function () {
        var k;
        $(this).val('');
        $('#comps').hide();
        $('#success').hide();
        if (compLines.length > 0) {
            compLines.forEach( function(line) {line.setMap(null);});
        }
        compLines = [];
        google.maps.event.clearListeners(mapCanvas, 'click');
        parcels.forEach(function (parcel) {
            parcel.marker.setMap(null);
            parcel.marker = null;
        });
        parcels = [];
        ourVertices = [];
        ourLines.forEach(function (line) {
            line.setMap(null);
        });
        ourLines = [];
        for (k = 0; k < 6; k++ ) {
            $('#tableCount' + k).text('');
            $('#tableRange' + k).text('');
        };
        targetMarker.setMap(null);
        mapCanvas.setZoom(4);
        mapCanvas.setCenter(35.99, -96.92);
        currentParcel = null;
    });
    $('#comps').hide();
    $('#address').val('');
});