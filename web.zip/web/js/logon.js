
$(document).ready(function() {
    'use strict';
    var url = window.location.href.slice(0,4) === 'file' ?
        'http://localhost:61116/logon' : 'http://www.leadelitepro.com:61116/logon';
    document.getElementById('login-button').onclick = function() {
        var xhr = XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        if($('#remember-me').prop('checked', true)){
            setCookie('username', $('#username').val(), 'password', $('#password').val(), 1000) ;
        }
        xhr.open('POST',url, true);
        xhr.setRequestHeader("Content-Type", 'application/json');
        xhr.onreadystatechange = function () {
            if ((xhr.readyState === 4) && (xhr.status === 200)) {
                if (xhr.responseText != '') {
                    var str = JSON.parse(xhr.responseText).firstName;
                    window.location = './home/index.html?firstname=' + encodeURIComponent(str);
                } else {
                    alert('Error, please try again');
                    location.reload(true);
                }
            }
        };
        xhr.send(JSON.stringify({
            username : $('#username').val(),
            password : $('#password').val()
        }));
    };
    function setCookie(cnameName,cvalueName, cnamePassword, cvaluePassword,exdays) {
        var d = new Date();
        d.setTime(d.getTime()+(exdays*24*60*60*1000));
        var expires = 'expires='+d.toGMTString();
        document.cookie = cnameName + '=' + cvalueName + '; ' +   expires;
        document.cookie = cnamePassword + '=' + cvaluePassword + '; ' + expires;
    }
    function getCookie(cname) {
        var name = cname + "=",
            ca = document.cookie.split(';'),
            i;
        for(i=0; i < ca.length; i++)
        {
            var c = ca[i].trim();
            if (c.indexOf(name)==0) return c.substring(name.length,c.length);
        }
        return '';
    }
    $('#username').click(function() {
        $('#username').val('');
    });
    $('#username').click(function() {
        $('#password').val('');
    });
    if(getCookie('username')) {
        $('#username').val(getCookie('username'));
    }
    if(getCookie('password')) {
        $('#password').val(getCookie('password'));
    }
    $('#remember-me').prop('checked', false);
});