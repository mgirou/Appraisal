$(document).ready(function() {
    'use strict';
    $('#inspector-image').click( function() {
        window.location = '../inspector/index.html';

    });
    $('#prospector-image').click( function() {
        window.location = '../prospector/index.html';
    });
    $('#servicer-image').click( function() {
        window.location = '../servicer/index.html';
    });
    $('#faq-image').click( function() {
        window.location = '../faq/index.html';

    });
    $('#policer-image').click( function() {
        window.location = '../policer/index.html';
    });
    $('#about-image').click( function() {
        window.location = '../about/index.html';
    });
    $('#applications-image').click( function() {
        window.location = '../applications/index.html';
    });
});