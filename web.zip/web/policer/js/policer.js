$(document).ready(function () {
    'use strict';
    rta.Parcel.prototype = {
        populateInfoWindowData: function () {
            rta.populateInfoWindowData(this);
        },
        title: function () {
            return rta.title(this);
        }
    };
    var marker,
        county,
        countyName,
        data = [],
        parcels = [],
        ourLines = [],
        ourVertices = [],
        countyPolygon,
        countyVertices = [],
        bounds = new google.maps.LatLngBounds(),
        mapCenter =  new google.maps.LatLng(35.99, -96.92),
        mapCanvas = new google.maps.Map(document.getElementById('map-canvas-area'), {
            zoom : 5,
            center : mapCenter,
            scaleControl : true,
            zoomControl: true,
            panControl: false,
            draggableCursor : 'crosshair',
            streetViewControl : true,
            streetViewControlOptions: {
            },
            mapTypeId : google.maps.MapTypeId.HYBRID,
            mapTypeControlOptions : {
                position: google.maps.ControlPosition.LEFT_TOP,
                style: google.maps.MapTypeControlStyle.HORIZONTAL
            }
        }),
        infoBoxOptions = {
            content: document.getElementById('infoWindowData')
        },
        infoWindow = new InfoBox(infoBoxOptions),
        icons = [{url: '../shared/images/blue-16x26.png'}, {url: '../shared/images/green-16x26.png'}, {url: '../shared/images/orange-16x26.png'},
            {url: '../shared/images/pink-16x26.png'}, {url: '../shared/images/red-16x26.png'}],
        clickedParcel = null,
        priceMin = 0,
        priceMax = 4000000,
        residenceMin = 0,
        residenceMax = 40,
        anniversaryMin = 1,
        anniversaryMax = 12,
        stage1Parcels,
        filterData = function filterData() {
            var today = new Date(),
                purchaseDate,
                selectionType,
                minVal = 999999999,
                maxVal = -1;
            parcels.forEach(function (parcel) {
                parcel.marker.setMap(null);
            });
            stage1Parcels = data.filter(function (parcel) {
                selectionType = $('input:radio[name=selection-type]:checked').val();
                if (selectionType === 'all') return true;
                if ((selectionType === 'disabled') && (parcel.disabled || parcel.vet)) return true;
                if ((selectionType === 'homesteadable') && !parcel.homesteaded && parcel.homesteadable) return true;
                if ((selectionType === 'deferrable') && !parcel.deferred && (parcel.senior ||parcel.disabled ||
                    parcel.vet)
                    ) return true;
                if ((selectionType === 'senior') && parcel.senior) return true;
                return false;
            });
            parcels = stage1Parcels.filter(function (parcel, jj) {
                purchaseDate = rta.decodeDate(countyName, parcel.deedDate);
                if((parcel.totalVal < priceMin) || ((priceMax < 4000000) && (parcel.totalVal > priceMax))) {
                    return false;
                }
                if((!$('#residence-checkbox').prop('checked') && (purchaseDate.year === 0)) ||
                  ($('#residence-checkbox').prop('checked') &&
                      (today < new Date(purchaseDate.year + residenceMin, purchaseDate.month, purchaseDate.day)) &&
                      (purchaseDate.year > 0))  ||
                  ($('#residence-checkbox').prop('checked') &&
                      (today > new Date(purchaseDate.year + residenceMax, purchaseDate.month, purchaseDate.day)) &&
                      (purchaseDate.year > 0))) {
                    return false;
                }
                if((!$('#anniversary-checkbox').prop('checked') && (purchaseDate.year === 0)) ||
                  ($('#anniversary-checkbox').prop('checked') &&
                      (purchaseDate.month < anniversaryMin) && (purchaseDate.year > 0))  ||
                  ($('#anniversary-checkbox').prop('checked') &&
                      (purchaseDate.month > anniversaryMax)&& (purchaseDate.year > 0))) {
                    return false;
                }
                marker = new google.maps.Marker({position: parcel.geoPos, map : mapCanvas, title: parcel.title()});
                marker.parcel = parcel;
                parcel.marker = marker;
                google.maps.event.addListener(marker, 'click', function () {
                    var clickedMarker = this;
                    if (!mapCenter) {
                        mapCenter = mapCanvas.getCenter();
                    }
                    clickedParcel = clickedMarker.parcel;
                    $('#infoWindowData').css('display', 'block');
                    clickedParcel.populateInfoWindowData();
                    infoWindow.setContent('<div id =infoWindowData>' + $('#infoWindowData').html() + '</div>');
                    infoWindow.open(mapCanvas, clickedMarker);
                });
                minVal = (parcel.houseValPerSqft < minVal) ? parcel.houseValPerSqft : minVal;
                maxVal = (parcel.houseValPerSqft > maxVal) ? parcel.houseValPerSqft : maxVal;
                return true;
            });
            var countBuckets = [0, 0, 0, 0, 0],  // how many parcels are in each quintile
                quintileSize = (maxVal <= minVal) ? 1 : (maxVal - minVal) / 5;  //5 is number of buckets
            parcels.forEach(function (parcel) {
                var slot = Math.min(Math.floor((parcel.houseValPerSqft - minVal) / quintileSize), 4);
                countBuckets[slot]++;
                parcel.marker.setIcon(icons[slot]);
            });
            countBuckets.forEach(function (bucket, k) {
                $('#tableCount' + k).text(rta.addCommas(bucket));
                $('#tableRange' + k).text(((minVal + k * quintileSize).toFixed(2)) + '-' +
                    ((minVal + (k + 1) * quintileSize).toFixed(2)));
            });
            $('#tableCount5').text(rta.addCommas(parcels.length));
            $('#tableRange5').text(minVal.toFixed(2) + '-' +
                (maxVal.toFixed(2)));
        },
        rtaAlert = function rtaAlert(message) {
            $('#dialog-text').text(message);
            $('#dialog').dialog({
                modal: true,
                position: {my: "left top", at: "left+10% bottom-30%", of: '#control-panel'}
            });
        };
    $('#neighborhood-begin').click(function () {
        bounds = new google.maps.LatLngBounds();
        ourVertices = [];
        ourLines.forEach(function (line) {
            line.setMap(null);
        });
        ourLines = [];
        google.maps.event.addListener(mapCanvas, 'click', function (event) {
            var vertexCount = ourVertices.push(event.latLng);
            bounds.extend(event.latLng);
            if (vertexCount >= 2) {
                ourLines.push(new google.maps.Polyline({
                    path: [ourVertices[vertexCount - 2], ourVertices[vertexCount - 1]],
                    strokeColor: "#fff000",
                    strokeWeight: 2,
                    strokeOpacity: 1.0,
                    map: mapCanvas
                }));
            } else {
                new google.maps.Geocoder().geocode({'latLng': ourVertices[0]}, function (results, status) {
                    if (status === google.maps.GeocoderStatus.OK) {
                        try {
                            county = rta.County.byGeocoderResult(results[0]);
                        } catch (e) {
                            rtaAlert('The first click was in an unsupported county, please start over');
                            return;
                        }
                    } else {
                        rtaAlert('Unable to reach Google geocoding online-please try again');
                    }
                });
            }
        });
    });
    $('#neighborhood-end').click(function () {
        if (ourVertices.length < 3) {
            rtaAlert('You need three points already selected before the polygon can be completed');
            return;
        }
        google.maps.event.clearListeners(mapCanvas, 'click');
        parcels.forEach(function (parcel) {
            parcel.marker.setMap(null);
            parcel.marker = null;
        });
        parcels = [];
        ourLines.push(new google.maps.Polyline({
            path: [ourVertices[ourVertices.length - 1], ourVertices[0]],
            strokeColor: "fff000",
            strokeWeight: 2,
            strokeOpacity: 1.0,
            map: mapCanvas
        }));
        mapCanvas.fitBounds(bounds);
        $('#working').show();
        county.getParcels(new rta.GeoPolygon(ourVertices), function (stuff) {
            $('#working').hide();
            data = stuff;
            filterData();
        });
    });
    $('#customize-apply').click(function () {
        filterData();
    });
    $('#price-range').slider({
            range: true,
            min: 0,
            max: 4000000,
            values: [0, 4000000],
            step: 10000,
            slide: function( event, ui ) {
                $('#price-amount').text(rta.addCommas('Price range: $ ' + ui.values[0] + ' - $ ' + ui.values[1]));
                priceMin = ui.values[0];
                priceMax = ui.values[1];
            }
        });
    $('#price-amount').text(rta.addCommas('House price range: $ ' + $('#price-range').slider('values', 0) + ' - $ ' +
        $('#price-range').slider('values', 1)));
    $('#residence-range').slider({
            range: true,
            min: 0,
            max: 40,
            values: [0, 40],
            step: 1,
            slide: function( event, ui ) {
                $('#residence-period').text(rta.addCommas('Time in house range: ' + ui.values[0] + ' - ' + ui.values[1]) +
                    ' years');
                residenceMin = ui.values[0];
                residenceMax = ui.values[1];
            }
        });
    $('#residence-period').text(rta.addCommas('Time in house: ' + $('#residence-range').slider('values', 0) +
        ' - ' + $('#residence-range').slider('values', 1)) + ' years');
    $('#anniversary-range').slider({
            range: true,
            min: 0,
            max: 11,
            values: [0, 11],
            step: 1,
            slide: function( event, ui ) {
                $('#anniversary-period').text('Closing month: ' + ['Jan','Feb','Mar','Apr','May','Jun',
                'Jul','Aug','Sep','Oct','Nov','Dec'][ui.values[0]] + ' - ' +  ['Jan','Feb','Mar','Apr','May','Jun',
                    'Jul','Aug','Sep','Oct','Nov','Dec'][ui.values[1]]);
                anniversaryMin = ui.values[0] + 1;
                anniversaryMax = ui.values[1] + 1;
            }
        });
    $('#anniversary-period').text('Closing month: Jan - Dec');
    $('#select-county-box').click(function () {
        var location;
        countyName =  $('#select-county-box').val();
        countyVertices = [];
        if(countyPolygon) countyPolygon.setMap(null);
        bounds = new google.maps.LatLngBounds();
        rta.findCountyVertices(countyName).forEach(function (vertex) {
            location =  new google.maps.LatLng(vertex[0], vertex[1]);
            countyVertices.push(location);
            bounds.extend(location);
        });
        countyPolygon = new google.maps.Polygon({
            paths: countyVertices,
            strokeColor: "#ff0000",
            strokeOpacity: 1.0,
            fillColor: "#ff0000",
            fillOpacity: 0.05,
            strokeWeight: 2,
            map: mapCanvas
        });
        google.maps.event.addListener(countyPolygon, 'click', function(event){
            google.maps.event.trigger(mapCanvas, 'click', event);
        });
        mapCanvas.fitBounds(bounds);
        mapCanvas.setZoom(11);
    });
    $('#save-button').click(function () {
        rtaAlert("The implementation of 'Upload' will be based on the client's needs for data sharing and storage.");
    });
    $('#view-button').click(function () {
        rtaAlert("The implementation of 'View' will be based on the client's needs for data formatting.");
    })
    google.maps.event.addListener(infoWindow, 'closeclick', function () {
        if (mapCenter) {
            mapCanvas.panTo(mapCenter);
        }
        mapCenter = null;
    });
    google.maps.event.addListener(mapCanvas, 'bounds_changed', function() {
    });
    ['zoom_changed', 'dragend', 'dragstart', 'drag', 'projection_changed', 'resize', 'tilt_changed'].forEach(
        function (eventName) {
            google.maps.event.addListener(mapCanvas, eventName, function () {
                mapCenter = null;
            });
        }
    );
    $('input:radio[name=selection-type]')[0].checked = true;
    $('#working').hide();
    $('.cb').prop('checked', true);
});